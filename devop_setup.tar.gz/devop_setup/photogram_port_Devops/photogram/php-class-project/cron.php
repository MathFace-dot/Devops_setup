<?php

file_put_contents('cronlog.txt', time()."\n", FILE_APPEND);
?>