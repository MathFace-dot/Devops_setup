| Service        | URL to Open in Browser                         | Description               |
| -------------- | ---------------------------------------------- | ------------------------- |
| **Photogram**  | [http://localhost:8080](http://localhost:8080) | Your main PHP app         |
| **phpMyAdmin** | [http://localhost:8088](http://localhost:8088) | MySQL web UI (phpMyAdmin) |
| **Adminer**    | [http://localhost:8089](http://localhost:8089) | MySQL web UI (Adminer)    |

